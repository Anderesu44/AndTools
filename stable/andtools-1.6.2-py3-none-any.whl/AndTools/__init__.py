__author__ = "Andev"
from .Types import Version as V
__version__ = V(1,6,2)

__doc__ = "Andev Tools"
